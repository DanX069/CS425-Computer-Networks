import random

def bit_string(k):
    return ''.join(random.choice('01') for _ in range(k))

def string_xor(a, b, index=0):
    a = list(a)
    for i, bit in enumerate(b):
        a[index + i] = str(int(bit != a[index + i]))
    return ''.join(a)

def find_remainder(dividend, divisor):
    for i in range(len(dividend)):
        if dividend[i] == '1':
            if i + len(divisor) <= len(dividend):
                dividend = string_xor(dividend, divisor, i)
    return dividend[len(dividend)-len(divisor)+1:]

def find_crc(message, polynomial):
    message += '0' * (len(polynomial) - 1)
    return find_remainder(message, polynomial)

def validate_fcs(fcs, polynomial):
    remainder = find_remainder(fcs, polynomial)
    return all(bit == '0' for bit in remainder)

def generate_crc_and_validate():
    n = int(input("Enter the frame size (n): "))
    k = int(input("Enter the message size (k): "))

    # Generate random message and polynomial
    m = bit_string(k)
    p = '1' + bit_string(n - k)
    
    crc = find_crc(m, p)
    fcs = m + crc
    isValid = validate_fcs(fcs, p)
    
    print(f"\nMessage (M): {m}")
    print(f"Polynomial (P): {p}")
    print(f"CRC: {crc}")
    print(f"Frame Check Sequence (FCS): {fcs}")
    print("Validity: " + ("Valid" if isValid else "Invalid") + "\n")

def main():
    print("Generating CRC and checking validity for the first set of inputs:")
    generate_crc_and_validate()

    print("Generating CRC and checking validity for the second set of inputs:")
    generate_crc_and_validate()

if __name__ == "__main__":
    main()

