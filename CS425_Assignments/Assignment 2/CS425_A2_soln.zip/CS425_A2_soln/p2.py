import random

def bit_string(k):
    return ''.join(random.choice('01') for _ in range(k))

def string_xor(a, b, index=0):
    a = list(a)
    for i, bit in enumerate(b):
        a[index + i] = str(int(bit != a[index + i]))
    return ''.join(a)

def find_remainder(dividend, divisor):
    for i in range(len(dividend)):
        if dividend[i] == '1':
            if i + len(divisor) <= len(dividend):
                dividend = string_xor(dividend, divisor, i)
    return dividend[len(dividend)-len(divisor)+1:]

def find_fcs(message, polynomial):
    message += '0' * (len(polynomial) - 1)
    return message[:len(message)-len(polynomial)+1] + find_remainder(message, polynomial)

def add_errors(t, num_errors=1):
    t_list = list(t)
    bit_positions = random.sample(range(len(t)), num_errors)  # Choose random positions to flip
    for pos in bit_positions:
        t_list[pos] = '1' if t_list[pos] == '0' else '0'  # Flip the bit at each chosen position
    return ''.join(t_list)

def check_valid(t, polynomial):
    remainder = find_remainder(t, polynomial)
    validity_message = "Valid! Zero remainder detected." if '1' not in remainder else f"Invalid! Non-zero remainder detected. Remainder: {remainder}"
    print(validity_message)
    return validity_message  # To explicitly indicate the function's purpose

def introduce_errors_and_validate():
    k = 10  # Message size
    polynomial = "110101"  # Given polynomial
    m = bit_string(k)
    t = find_fcs(m, polynomial)
    print(f"Message Bits (M): {m}")
    print(f"Polynomial (P): {polynomial}")
    print(f"Original Transmission Frame (T): {t}")
    
    # Introduce a random number of errors; you can adjust num_errors as needed
    num_errors = random.randint(1, len(t)//2)  # For example, up to half of the bits might be flipped
    t_with_errors = add_errors(t, num_errors)
    print(f"Transmission Frame after Introducing Errors: {t_with_errors}")
    
    # Check validity, print the result, and the remainder
    check_valid(t_with_errors, polynomial)

introduce_errors_and_validate()

